Code by A. Meucci, May 2009, complements the article
	
	A. Meucci (2009) 
	"Review of Statistical Arbitrage, Cointegration, and Multivariate Ornstein-Uhlenbeck"

	available at ssrn.com

The most recent version of this code available at
	www.symmys.com > Teaching > MATLAB


Run files named "S_...", which are scripts

No claim of accuracy is made and no responsibility is taken for possible errors 
These files can and must be used and distributed freely
Please quote the author and the source: "Attilio Meucci - www.symmys.com".
Your feedback is highly appreciated